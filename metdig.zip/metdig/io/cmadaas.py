from metdig_io.cmadaas import get_model_grid
from metdig_io.cmadaas import get_model_grids
from metdig_io.cmadaas import get_model_3D_grid
from metdig_io.cmadaas import get_model_3D_grids
from metdig_io.cmadaas import get_model_points # 返回的是pandas.DataFrame的站点数据
from metdig_io.cmadaas import get_model_station # 返回的是xarray.DataArray的站点数据

# 实况相关
from metdig_io.cmadaas import get_obs_stations
from metdig_io.cmadaas import get_obs_stations_multitime
