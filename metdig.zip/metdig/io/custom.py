# 模式相关
from metdig_io.custom import split_stda_to_cache
from metdig_io.custom import split_stda_to_cache as split_stda_to_cache_sfc
from metdig_io.custom import split_stda_to_cache as split_stda_to_cache_psl
from metdig_io.custom import get_model_grid
from metdig_io.custom import get_model_grids
from metdig_io.custom import get_model_3D_grid
from metdig_io.custom import get_model_3D_grids
from metdig_io.custom import get_model_points # 返回的是pandas.DataFrame的站点数据
from metdig_io.custom import get_model_station # 返回的是xarray.DataArray的站点数据