from . import boxplot_method
from . import barbs_method
from . import scatter_method
from . import streamplot_method
from . import contour_method
from . import contourf_method
from . import draw_compose
from . import other_method
from . import pallete_set
from . import pcolormesh_method
from . import quiver_method
from . import text_method
from . import plot_method

from . import lib
from . import cmap