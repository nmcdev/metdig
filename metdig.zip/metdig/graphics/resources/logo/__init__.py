"""
nmc_met_map is a package that providing tools to proceed the diagnostic analysis.
Including pyhsical parameter calculation and figure ploting.
"""

__author__ = "The R & D Center for Weather Forecasting Technology in NMC, CMA"
__version__ = '0.1.0'