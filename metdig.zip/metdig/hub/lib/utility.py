# -*- coding: utf-8 -*-


import io
import sys
import os
import datetime
import copy

import imageio
import numpy as np
import numba as nb
import matplotlib.pyplot as plt
import PIL.Image as PILImage

from concurrent import futures

from IPython.display import Image, display
from io import BytesIO

import logging
_log = logging.getLogger(__name__)


def get_labels_dist(num):
    '''
    [获取label类型图的分布]
    '''
    if num == 1:
        return (1, 1)
    if num == 2:
        return (1, 2)

    if num > 2 and num <= 4:
        return (2, 2)

    if num > 4 and num <= 9:
        return (3, 3)

    if num > 9 and num <= 16:
        return (4, 4)
    if num > 16 and num <= 25:
        return (5, 5)


def get_nearest_init_time(fhour, data_source='', data_name='', func=None, func_other_args={}):
    '''
    以系统时间为起点， 获取最近fhour时预报的起报时间
    '''

    # 以系统时间为起点，固定fhour=0，逐1小时往前推，直至取到第一对init_time fhour=0，目的是获得最近的一次000时效预报数据
    sys_time = datetime.datetime.now().strftime('%Y%m%d%H')  # 系统时间
    sys_time = datetime.datetime.strptime(sys_time, '%Y%m%d%H')
    tag = False
    for i in range(24):  # 逐个往前推
        func_args = copy.deepcopy(func_other_args)
        func_args['init_time'] = sys_time - datetime.timedelta(hours=i)
        func_args['fhour'] = 0
        func_args['data_name'] = data_source
        func_args['data_name'] = data_name
        func_args['is_return_imgbuf'] = True
        func_args['is_draw'] = False # 由于one_step增加is_draw参数，此处仅读取数据不绘图增加效率
        ret = mult_process(func=func, func_args_all=[func_args], max_workers=1, force_max_workers=True)
        if len(ret) > 0:
            tag = True
            break
        else:
            _log.info(f'''{func_args['init_time']} {func_args['fhour']} {data_name} find failed. next.''')
    if tag == True:
        # 取到第一对init_time fhour
        _log.info(f'''{func_args['init_time']} {func_args['fhour']} {data_name} find success. end.''')
        return func_args['init_time']
    else:
        raise Exception('can not get any data! init_time=[{:%Y%m%d%H}-{:%Y%m%d%H}] fhour=24'.format(sys_time, sys_time - datetime.timedelta(hours=23)))
        return None

    return None


def mult_process(func=None, func_args_all=[], max_workers=6, force_max_workers=True):
    '''

    [多进程绘图]

    Keyword Arguments:
        func {[type]} -- [函数 or list] (default: {None})如果是函数，list长度须于func_args_all一致
        func_args_all {list} -- [函数参数] (default: {[]})
        max_workers {number} -- [进程池大小] (default: {6})
        force_max_workers {bool} -- [是否强制使用max_workers参数，默认关闭] (default: {False})

    Returns:
        [list] -- [有效的返回结果]
    '''
    if len(func_args_all) == 0:
        return []

    # 多进程绘图
    if force_max_workers == False:
        use_sys_cpu = max(1, os.cpu_count() - 2)  # 可使用的cpu核心数为cpu核心数-2
        max_workers = min(max_workers, use_sys_cpu)  # 最大进程数
    _log.debug('cpu_count={}, use max_workers={}'.format(os.cpu_count(), max_workers))

    all_ret = []
    # with futures.ProcessPoolExecutor(max_workers=max_workers) as executer:
    # 提交所有绘图任务
    executer=futures.ProcessPoolExecutor(max_workers=max_workers)
    if(isinstance(func,list)):
        all_task = [executer.submit(func[_ifunc], **_) for _ifunc,_ in enumerate(func_args_all)]
    else:
        all_task = [executer.submit(func, **_) for _ in func_args_all]

    # 等待
    futures.wait(all_task, return_when=futures.ALL_COMPLETED)

    # 取返回值
    for task in all_task:
        exp = task.exception()
        if exp is None:
            all_ret.append(task.result())
        else:
            _log.debug(exp)
            pass
    executer.shutdown()
    return all_ret


def save_animation(img_bufs, output_dir, gif_name, fps=2, is_clean_plt=True):
    '''
    保存成gif
    '''
    if len(img_bufs) == 0:
        return None
    gif_path = None
    if output_dir:
        gif_path = os.path.join(output_dir, gif_name)
        # with imageio.get_writer(gif_path, format='GIF', mode='I', fps=fps, loop=0) as writer:
        with imageio.get_writer(gif_path, format='GIF', mode='I', fps=1/fps*1000, loop=0) as writer:
            for imgbuf in img_bufs:
                writer.append_data(imgbuf)

    if is_clean_plt == False:
        gif_path = BytesIO()
        # with imageio.get_writer(gif_path, format='GIF', mode='I', fps=fps, loop=0) as writer:
        with imageio.get_writer(gif_path, format='GIF', mode='I', fps=1/fps*1000, loop=0) as writer:
            for imgbuf in img_bufs:
                writer.append_data(imgbuf)
        img = Image(data=gif_path.getvalue())
        display(img)

    return gif_path


def save_tab(img_bufs, output_dir=None, png_name=None, tab_size=(30, 18),tab_dist=None, is_clean_plt=True):
    '''
    保存成tab，多图叠加
    '''
    if len(img_bufs) == 0:
        return None
    # 开始绘图
    fig = plt.figure(figsize=tab_size)
    if(tab_dist is None):
        nrows, ncols = get_labels_dist(len(img_bufs))
    else:
        nrows=tab_dist[0]
        ncols=tab_dist[1]
    for i, imgbuf in enumerate(img_bufs):
        ax = fig.add_subplot(nrows, ncols, i + 1)
        ax.axis('off')
        ax.imshow(imgbuf)
    plt.tight_layout()  # 调整整体空白
    plt.subplots_adjust(wspace=0.02, hspace=0.02)  # 调整子图间距

    # 输出
    png_path = None
    if output_dir:
        png_path = os.path.join(output_dir, png_name)
        plt.savefig(png_path, dpi=100, bbox_inches='tight')

    if is_clean_plt:
        plt.close(fig)
    
    

    return png_path


def compose_rgba(img_bufs, output_dir=None, png_name=None, tab_dist=None, fill_pecent=0):
    """[根据rgba列表，多图合并]

    Args:
        img_bufs ([list]): [多个rgba组成的list]
        output_dir ([str]): [输出文件]
        png_name ([str]): [输出文件]
        tab_dist ([int]], optional): [组成的新图的行数,列数(row, col)]. Defaults to None.
        fill_pecent (float, optional): [小图间距百分比，原理是各个小图在外围增加N圈白色像素，然后再组合成大图]]. Defaults to 1.
    """
    if(tab_dist is None):
        row, col = get_labels_dist(len(img_bufs))
    else:
        row=tab_dist[0]
        col=tab_dist[1]

    N = len(img_bufs)
    if N < col:
        col = N

    newrgbalst = []
    for n in range(N):
        buf = img_bufs[n]
        fill_xpix = int(buf.shape[0] * fill_pecent / 100)
        fill_ypix = int(buf.shape[1] * fill_pecent / 100)
        buf_copy = np.full((buf.shape[0] + fill_xpix*2, buf.shape[1] + fill_ypix*2, buf.shape[2]), 255, dtype=np.uint8)
        buf_copy[fill_xpix:buf.shape[0]+fill_xpix, fill_ypix:buf.shape[1]+fill_ypix, :] = buf

        newrgbalst.append(buf_copy)
    
    newrgbalst = img_bufs

    row, col = auto_rc(N, row=row, col=col)

    if row is None and col is None:
        row = int(np.ceil(np.sqrt(N)))
        if N % row == 0:
            col = int(N / row)
        else:
            col = int(np.ceil(N / row))

    max_pix_r = max([buf.shape[0] for buf in newrgbalst])
    max_pix_c = max([buf.shape[1] for buf in newrgbalst])

    rgbabuf = np.full((max_pix_r * row, max_pix_c * col, 4), 255, dtype=np.uint8)

    for ir in range(row):
        for ic in range(col):
            n = ir * col + ic
            if n >= N:
                continue
            buf = newrgbalst[n]

            paste_st_row = ir * max_pix_r
            paste_en_row = ir * max_pix_r + buf.shape[0]

            paste_st_col = ic * max_pix_c
            paste_en_col = ic * max_pix_c + buf.shape[1]

            rgbabuf[paste_st_row: paste_en_row, paste_st_col: paste_en_col, :buf.shape[2]] = buf
    
    if output_dir:
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        outpng = os.path.join(output_dir, png_name)
        image = PILImage.fromarray(rgbabuf.astype(np.uint8), mode='RGBA')
        image.save(outpng)
    
    return rgbabuf



def save_list(img_bufs, output_dir, png_paths, list_size=(16, 9), is_clean_plt=True):
    '''
    保存成list，多图分开绘制
    '''
    png_path_list = []
    for imgbuf, png_path in zip(img_bufs, png_paths):
        fig = plt.figure(figsize=list_size)
        ax = fig.add_subplot(111)
        ax.axis('off')
        ax.imshow(imgbuf)
        plt.tight_layout()  # 调整整体空白
        plt.subplots_adjust(wspace=0.02, hspace=0.02)  # 调整子图间距# 输出
        if output_dir:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            outpng = os.path.join(output_dir, png_path)
            png_path_list.append(outpng)
            plt.savefig(outpng, dpi=200, bbox_inches='tight')
        if is_clean_plt:
            plt.close(fig)
    return png_path_list


def get_onestep_ret_imgbufs(all_ret):
    imgbufs = []
    for ret in all_ret:
        if ret is None:
            continue 
        if 'img_buf' in ret.keys():
            imgbufs.append(ret['img_buf'])
    return imgbufs

def get_onestep_ret_pngnames(all_ret):
    pics = []
    for ret in all_ret:
        if ret is None:
            continue 
        if 'png_name' in ret.keys():
            pics.append(ret['png_name'])
    return pics

def strparsetime(dt):
    # 字符型日期转datetime
    if isinstance(dt, str):
        if len(dt) == 10:
            dt = datetime.datetime.strptime(dt, '%Y%m%d%H')
        elif len(dt) == 8:
            dt = datetime.datetime.strptime(dt, '%y%m%d%H')
        else:
            raise Exception('time must be datetime or str like 2001010100(%Y%m%d%H) or str like 01010100(%y%m%d%H)')
    return dt




def auto_rc(N, row=None, col=None):
    if N == 1:
        return 1, 1
    if row == None and col == None:
        row = int(np.round(np.sqrt(N)))
        col = int(np.ceil(N / row))

    elif row == None and col != None:
        row = int(np.ceil(N / col))

    elif row != None and col == None:
        col = int(np.ceil(N / row))

    return row, col